<?php

namespace App\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * @ORM\Entity(repositoryClass="App\Repository\CreditCalcRepository")
 */
class CreditCalc
{
    /**
     * @ORM\Id()
     * @ORM\GeneratedValue()
     * @ORM\Column(type="integer")
     */
    private $id;

    /**
     * @ORM\Column(type="float")
     */
    private $Amount;

    /**
     * @ORM\Column(type="integer")
     */
    private $Term;

    /**
     * @ORM\Column(type="float")
     */
    private $Percent;

    /**
     * @ORM\Column(type="date")
     */
    private $fpdate;

    /**
     * @ORM\Column(type="array")
     */
    private $Result;

    /**
     * @ORM\Column(type="string", length=255, nullable=true)
     */
    private $Description;

    public function getId()
    {
        return $this->id;
    }

    public function getAmount(): ?float
    {
        return $this->Amount;
    }

    public function setAmount(float $Amount): self
    {
        $this->Amount = $Amount;

        return $this;
    }

    public function getTerm(): ?int
    {
        return $this->Term;
    }

    public function setTerm(int $Term): self
    {
        $this->Term = $Term;

        return $this;
    }

    public function getPercent(): ?float
    {
        return $this->Percent;
    }

    public function setPercent(float $Percent): self
    {
        $this->Percent = $Percent;

        return $this;
    }

    public function getFpdate(): ?\DateTimeInterface
    {
        return $this->fpdate;
    }

    public function setFpdate(\DateTimeInterface $fpdate): self
    {
        $this->fpdate = $fpdate;

        return $this;
    }

    public function getResult(): ?array
    {
        return $this->Result;
    }

    public function setResult(array $Result): self
    {
        $this->Result = $Result;

        return $this;
    }

    public function getDescription(): ?string
    {
        return $this->Description;
    }

    public function setDescription(?string $Description): self
    {
        $this->Description = $Description;

        return $this;
    }
}
