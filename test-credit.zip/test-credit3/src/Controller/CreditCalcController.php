<?php

namespace App\Controller;

use App\Entity\CreditCalc;
use App\Form\CreditFormType;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;


class CreditCalcController extends Controller
{
    /**
     * @Route("/", name="credit_calc")
     */
    public function Credit(Request $request)
    {

        $entityManager = $this->getDoctrine()->getManager();

        $creditcalc = new CreditCalc();

        $form = $this->createForm(CreditFormType::class, $creditcalc);
        $form->handleRequest($request);

        if ( $request->isXmlHttpRequest() ) {
            if ($form->isSubmitted() && $form->isValid()) {
                /*
                $creditcalc->setAmount(10000);
                $creditcalc->setTerm(12);
                $creditcalc->setPercent(3);
                $creditcalc->setFpdate(date_create_from_format('j-M-Y', '15-Feb-2009'));
                $creditcalc->setResult([1,2,3]);

                $entityManager->persist($creditcalc);

                $entityManager->flush();
                */
                return array(
                    'result' => 0,
                    'message' => 'Invalid form',
                    'data' => $this->getErrorMessages($form));

                
            }
            return array(
                'result' => 1,
                'message' => 'ok',
                'data' => '');
            
        }

        return $this->render(
            'calc.html.twig',
            array('form' => $form->createView())
        );

        /*

        return $this->json([
            'message' => 'Welcome to your new controller!',
            'path' => 'src/Controller/CreditCalcController.php',
        ]);

        */
    }
    protected function getErrorMessages(\Symfony\Component\Form\Form $form) 
    {
        $errors = array();

        foreach ($form->getErrors() as $key => $error) {
            $errors[] = $error->getMessage();
        }

        foreach ($form->all() as $child) {
            if (!$child->isValid()) {
                $errors[$child->getName()] = $this->getErrorMessages($child);
            }
        }

        return $errors;
    }
}
