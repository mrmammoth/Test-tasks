<?php

namespace App\Controller;

use Symfony\Component\Routing\Annotation\Route;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\Request;
use App\Entity\CreditCalc;

class CalculateController extends Controller
{
    /**
     * @Route("/calc", name="calculate")
     */
    public function index()
    {
    	// get and parse this
	    $request = $_POST['credit_form'];

	    $my_Amount = $request['Amount'];
	    $my_Term = $request['Term'];
	    $my_Percent = $request['Percent'];
	    $my_fpdate = $request['fpdate'];
		    $my_fpdate_year = $my_fpdate['year'];
		    $my_fpdate_month = $my_fpdate['month'];
		    $my_fpdate_day = $my_fpdate['day'];
	    	$my_first_pay = date_create_from_format('j-m-Y', $my_fpdate_day .'-' . $my_fpdate_month . '-' . $my_fpdate_year);

	    // calc this

	    $i = ( $my_Percent / 12 ) / 100;
	    $percent_amount = $my_Amount * $i;
	    $n = $my_Term;
	    $S = $my_Amount;

	    $K = ($i*(1+$i)**$n)/((1+$i)**$n-1); 

	    $A = $K * $S; // const

	    // write form data

	    $entityManager = $this->getDoctrine()->getManager();

        $calc = new CreditCalc();

		$calc->setAmount($my_Amount);
        $calc->setTerm($my_Term);
        $calc->setPercent($my_Percent);
        $calc->setFpdate($my_first_pay);

        $calc->setDescription($A);

	    // Table

	    $array_res = Array();
	    
	    date_add($my_first_pay, date_interval_create_from_date_string('1 month'));

	    $j = 1;
	    array_push($array_res, [round($A,0)]);
	    array_push($array_res, [round($A * $my_Term,0)]);
	    array_push($array_res, [round($A * $my_Term - $my_Amount,0)]);
	    

	    while ( $j <= $my_Term) {
	    	array_push($array_res, [
	    		$j, 
	    		date_format($my_first_pay, 'd-M-Y'), 
	    		round($my_Amount,0), 
	    		round($percent_amount,0), 
	    		round($A - $percent_amount,0),
	    		round($my_Amount - ( $A - $percent_amount ),0)
	    		
	    	]);
	    	$my_Amount = $my_Amount - ( $A - $percent_amount );
	    	$percent_amount = $my_Amount * $i;

	    	date_add($my_first_pay, date_interval_create_from_date_string('1 month'));
	    	$j++;
	    }

	    // write result array for future investigations
	    
	    
        $calc->setResult($array_res);
        
        

        $entityManager->persist($calc);

        $entityManager->flush();


        return $this->json([
        	'result' => 0,
            'message' => 'ok',
            'data' => json_encode($array_res)]);
    }

}
