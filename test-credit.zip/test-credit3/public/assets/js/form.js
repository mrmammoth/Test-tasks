$("form").submit(function(e) {

    e.preventDefault();
    var formSerialize = $(this).serialize();

    var url = location.origin + '/calc';
    
    $.ajax({
        url: url,
        data: formSerialize,
        type: "POST",
        success: function(data) {
            if(data.result == 0) {
                $("#indicator").html("<span style='color:green';>Write Successfull</span>");
                var table = JSON.parse(data.data);
                var paym2m = table[0];
                var total_w_percent = table[1];
                var overpay = table[2];
                var tablestr = '<table class="table  table-striped table-bordered"><tbody>';
                tablestr += '<tr><th>No</th><th>Payment date<br><span style="font-size:11px;">Monthly payment : '+paym2m[0]+'</span></th><th>loan debt<br><span style="font-size:11px;">loan debt with interest : '+total_w_percent[0]+' ( '+overpay[0]+' )'+'</span></th><th>repayment of <br>interest on a loan</th><th>loan repayment</th><th>debt after payment</th></tr>'
                for (var i = 3; i < table.length; i++) {
                    tablestr += '<tr>';
                    var tablerow = table[i];
                    for (var j = 0; j < 6; j++) {
                        tablestr += '<td>';
                        tablestr += tablerow[j];
                        tablestr += '</td>';
                    }
                    tablestr += '</tr>';
                }
                tablestr += '</tbody></table>';
                $("#restable").html(tablestr);
            } else {
                alert('Error'+data.message);
            }
        },
        error: function(data){
            alert('Error'+data.message);
        }
    });
    
});

$("#reset_button").click(function() {
    $("#credit_form_Amount").val("");
    $("#credit_form_Term").val("");
    $("#credit_form_Percent").val("");
    $("#indicator").text("");
    $("#restable").html("");
    });