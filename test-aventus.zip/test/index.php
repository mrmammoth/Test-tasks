<?php
$arr_src = file("src.txt");
$arr_dest = explode(" ", $arr_src[0]);
array_unshift($arr_dest,""); // unshift one item to count from 1
$res_str = "";
$outfile = fopen("dest.txt", "w") or die("Directory write protected!");

for($i=1;$i<count($arr_dest);$i++){
	if($i/3==intdiv($i, 3)){
		$arr_dest[$i] = "Three";
	}
	if($i/5==intdiv($i, 5)){
		$arr_dest[$i] = "Five";
	}
	if($i/3==intdiv($i, 3) && $i/5==intdiv($i, 5)){
		$arr_dest[$i] = "Fifteen";
	}
	$res_str .= $arr_dest[$i] . " ";
	
}
fwrite($outfile, $res_str);
fclose($outfile);
echo("Successfull!");